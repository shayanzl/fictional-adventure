# spring-boot-library
Example project showing how a Spring Boot app can use a library that´s build with Spring itself

[![Build Status](https://travis-ci.org/jonashackt/spring-boot-library.svg?branch=master)](https://travis-ci.org/jonashackt/spring-boot-library)