package de.jonashackt.library.spring;

/**
 * This is the entry point to our library.
 */
public interface FooLibrary {
    double calculateProducts();
}
